from astromcad.astromcad import Detect
from astromcad.astromcad import mcad
from astromcad.astromcad import mcif
from astromcad.astromcad import build_model, train_contextual, train
from astromcad.astromcad import plot_recall, median_score, distribution